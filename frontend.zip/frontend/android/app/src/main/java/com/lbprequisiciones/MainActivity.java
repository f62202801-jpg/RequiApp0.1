package com.lbprequisiciones;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
